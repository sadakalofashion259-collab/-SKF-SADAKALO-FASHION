-- ============================================================
--  Sada Kalo Fashion — SMS Module Database Schema
--  ফোন/API সিক্রেট .env-এ থাকবে; মেসেজ টেমপ্লেট ও নন-সিক্রেট
--  গেটওয়ে সেটিং ডাটাবেজ থেকে এডিট করা যাবে।
--  charset: utf8mb4 (বাংলা সাপোর্ট)
-- ============================================================

-- ১) প্রতি সাপ্লায়ারে SMS চালু/বন্ধ কলাম।
--    ⚠️ MySQL-এ "ADD COLUMN IF NOT EXISTS" চলে না, তাই নিচের সাধারণ লাইন দেওয়া হলো।
--    কলাম আগে থেকেই থাকলে এই এক লাইনে "Duplicate column" এরর দেখাবে —
--    সেটা উপেক্ষা করে বাকি অংশ চালিয়ে যান (বা এই লাইনটি বাদ দিন)।
--    সবচেয়ে সহজ উপায়: phpMyAdmin না ঘেঁটে Suppliers/install.php একবার খুলুন।
ALTER TABLE `suppliers`
    ADD COLUMN `sms_enabled` TINYINT(1) NOT NULL DEFAULT 1;

-- ২) SMS পাঠানোর লগ (ড্যাশবোর্ডে "সাম্প্রতিক SMS" + পরিসংখ্যান এখান থেকে)
CREATE TABLE IF NOT EXISTS `sms_log` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `supplier_id` INT UNSIGNED NULL,
    `tr_id`       INT UNSIGNED NULL,
    `phone`       VARCHAR(20)  NOT NULL,
    `message`     TEXT         NOT NULL,
    `status`      ENUM('sent','failed','pending') NOT NULL DEFAULT 'pending',
    `trxn_id`     VARCHAR(100) NULL,
    `sent_by`     VARCHAR(100) NULL,
    `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_supplier` (`supplier_id`),
    KEY `idx_status`   (`status`),
    KEY `idx_created`  (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ৩) নন-সিক্রেট গেটওয়ে কনফিগ (Sender ID, টাইপ, চালু/বন্ধ — ড্যাশবোর্ড থেকে এডিটযোগ্য)
--    NOTE: username ও apikey কখনো ডাটাবেজে রাখা হয় না — ওগুলো .env-এ।
CREATE TABLE IF NOT EXISTS `sms_gateway` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `provider`    VARCHAR(50)  NOT NULL DEFAULT 'MiMSMS',
    `sender_id`   VARCHAR(50)  NOT NULL DEFAULT '8809617633941',
    `trans_type`  CHAR(1)      NOT NULL DEFAULT 'T',      -- T=Transactional, P=Promotional
    `campaign_id` VARCHAR(50)  NOT NULL DEFAULT 'null',
    `endpoint`    VARCHAR(255) NOT NULL DEFAULT 'https://api.mimsms.com/api/SmsSending/SMS',
    `is_enabled`  TINYINT(1)   NOT NULL DEFAULT 1,
    `updated_by`  VARCHAR(100) NULL,
    `updated_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sms_gateway` (`id`,`provider`,`sender_id`,`trans_type`,`campaign_id`,`endpoint`,`is_enabled`)
SELECT 1,'MiMSMS','8809617633941','T','null','https://api.mimsms.com/api/SmsSending/SMS',1
WHERE NOT EXISTS (SELECT 1 FROM `sms_gateway` WHERE `id`=1);

-- ৪) SMS মেসেজ টেমপ্লেট (এডমিন ড্যাশবোর্ড থেকে এডিট করা যাবে)
--    প্লেসহোল্ডার: {shop} {date} {memo} {bill} {pay} {due} {user}
CREATE TABLE IF NOT EXISTS `sms_templates` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `template_key` VARCHAR(60)  NOT NULL,
    `title`        VARCHAR(120) NOT NULL,
    `body`         TEXT         NOT NULL,
    `is_active`    TINYINT(1)   NOT NULL DEFAULT 1,
    `updated_by`   VARCHAR(100) NULL,
    `updated_at`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_key` (`template_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ডিফল্ট টেমপ্লেট (বিদ্যমান হার্ডকোড করা বার্তার হুবহু বিকল্প)
INSERT INTO `sms_templates` (`template_key`,`title`,`body`,`is_active`) VALUES
('transaction','লেনদেন / বিল-জমা বার্তা',
 '{shop}\nতারিখ: {date}\nমেমো: {memo}\nবিল: {bill} টাকা\nজমা: {pay} টাকা\nমোট বাকি: {due} টাকা\nধন্যবাদ - Sada Kalo Fashion', 1),
('test','টেস্ট বার্তা',
 'Sada Kalo Fashion — SMS পরীক্ষা বার্তা।', 1)
ON DUPLICATE KEY UPDATE `title`=VALUES(`title`);
