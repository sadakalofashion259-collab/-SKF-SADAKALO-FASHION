<?php
/**
 * VIEW: login/login_form.php
 * CSS: .login-box | .logo-wrapper | .logo | .main-title | .sub-title
 *      .msg-container | form | input | #loginBtn | .forgot-pass
 * Vars: $loginCsrfToken, $loginResultHtml
 */
?>
<div class="login-box">

    <!-- Logo -->
    <div class="logo-wrapper">
        <img src="logo.png" class="logo" alt="Sada Kalo Fashion">
    </div>

    <!-- Brand -->
    <div class="title-group">
        <h2 class="main-title">SADA KALO FASHION</h2>
        <div class="sub-title">দৈনিক হিসাব খাতা-2026</div>
    </div>

    <!-- Flash Message -->
    <?php if (!empty($loginResultHtml)): ?>
        <div class="msg-container"><?php echo $loginResultHtml; ?></div>
    <?php endif; ?>

    <!-- Form -->
    <form method="POST" action="index.php">
        <input type="hidden" name="csrf_token"
               value="<?php echo htmlspecialchars($loginCsrfToken ?? '', ENT_QUOTES, 'UTF-8'); ?>">

        <!-- Stage 1: CAPTCHA -->
        <div id="recaptcha-stage">
            <p class="captcha-welcome-text">Welcome To My Sada Kalo Fashion</p>
            <div class="cf-turnstile"
                 data-sitekey="0x4AAAAAADfIQjRCOxiHGO2k"
                 data-callback="onTurnstileSuccess"></div>
        </div>

        <!-- Stage 2: Login fields (hidden until CAPTCHA passes) -->
        <div id="login-stage">
            <input type="text"     name="username" placeholder="SADA KALO USER ID"
                   required autocomplete="username" autocapitalize="off" autocorrect="off">
            <input type="password" name="password" placeholder="PASSWORD"
                   required autocomplete="current-password">
            <button type="submit" name="login_btn" id="loginBtn">
                <i class="fas fa-sign-in-alt"></i> Sada Kalo
            </button>
        </div>
    </form>

    <!-- Forgot Password -->
    <a href="auth/otp_auth.php" class="forgot-pass">
        <i class="fas fa-shield-alt"></i> Reset &amp; Verify Password
    </a>

</div>
