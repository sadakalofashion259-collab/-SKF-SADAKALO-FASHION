<?php
/**
 * VIEW: login/login_scripts.php
 * Covers: slider auto-rotate | Turnstile callback | PWA SW
 */
?>
<script>
/* ── Image Slider ────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', function () {
    var slides = document.querySelectorAll('.slide');
    if (slides.length > 1) {
        var cur = 0;
        setInterval(function () {
            slides[cur].classList.remove('active');
            cur = (cur + 1) % slides.length;
            slides[cur].classList.add('active');
        }, 3000);
    } else if (slides.length === 1) {
        slides[0].classList.add('active');
    }
});

/* ── Cloudflare Turnstile Callback ───────────────────────────── */
function onTurnstileSuccess(token) {
    if (!token) return;
    var stage1 = document.getElementById('recaptcha-stage');
    var stage2 = document.getElementById('login-stage');
    if (stage1) stage1.style.display = 'none';
    if (stage2) stage2.style.display = 'flex';
    /* Auto-focus first input after CAPTCHA passes */
    var firstInput = stage2 ? stage2.querySelector('input[type="text"]') : null;
    if (firstInput) setTimeout(function () { firstInput.focus(); }, 100);
}
</script>
<script src="/pwa.js"></script>
